package com.legendary.arsenal;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/**
 * Eclipse Reaper. Active abilities (Shift+Right-Click cycles, Right-Click casts):
 *   0 Reaper Slash, 1 Shadow Dash, 2 Death Spiral, 3 Black Hole (ultimate)
 * Passives: Soul Harvest (kills grant souls = +8% damage each), Execution (<20% HP).
 */
public class EclipseReaperItem extends Item {
    public static final String[] NAMES = {"Reaper Slash", "Shadow Dash", "Death Spiral", "Black Hole (Ultimate)"};
    public static final int[] COOLDOWN = {24, 80, 220, 800};
    static final int WEAPON = 0;

    // ---- Soul Harvest state
    private static final class SoulData { int souls; long expires; }
    private static final Map<UUID, SoulData> SOULS = new HashMap<>();
    private static final int MAX_SOULS = 10, SOUL_TICKS = 300;

    public static int souls(ServerPlayer p) {
        SoulData d = SOULS.get(p.getUUID());
        if (d == null) return 0;
        if (Cooldowns.now(p) > d.expires) { d.souls = 0; return 0; }
        return d.souls;
    }
    public static double soulMult(ServerPlayer p) { return 1.0 + 0.08 * souls(p); }

    public static void onKill(ServerPlayer p, LivingEntity victim) {
        ServerLevel l = (ServerLevel) p.level();
        SoulData d = SOULS.computeIfAbsent(p.getUUID(), k -> new SoulData());
        if (Cooldowns.now(p) > d.expires) d.souls = 0;
        d.souls = Math.min(MAX_SOULS, d.souls + 1);
        d.expires = Cooldowns.now(p) + SOUL_TICKS;
        Vec3 from = Fx.mid(victim);
        Fx.sound(l, from, ModSounds.SOUL_HARVEST, 0.8f, 0.9f + d.souls * 0.04f);
        p.heal(2.0f);
        // soul streams flying from the victim to the player
        Vec3 to = p.position().add(0, 1.2, 0);
        Tasks.each(12, i -> {
            double t = (i + 1) / 12.0;
            Vec3 pt = from.add(to.subtract(from).scale(t)).add(0, Math.sin(t * Math.PI) * 1.2, 0);
            Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, pt, 2, 0.05, 0.05, 0.05, 0.01);
            Fx.part(l, Fx.dust(Fx.PURPLE, 1.0f), pt, 1, 0.05, 0.05, 0.05, 0);
            return false;
        });
    }

    public EclipseReaperItem(Properties props) { super(props); }

    // ------------------------------------------------------------------ passives
    @Override
    public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!(attacker instanceof ServerPlayer p) || !(p.level() instanceof ServerLevel l)) return;
        double atk = Fx.atk(p);
        float soulBonus = (float) ((soulMult(p) - 1.0) * atk);
        if (soulBonus > 0.1f) Fx.hit(l, p, target, soulBonus);
        Vec3 c = Fx.mid(target);
        Fx.part(l, Fx.dust(Fx.CRIMSON, 1.3f), c, 10, 0.3, 0.4, 0.3, 0);
        Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, c, 4, 0.25, 0.3, 0.25, 0.02);
        // Execution: below 20% HP -> massive bonus damage
        if (target.isAlive() && target.getHealth() <= target.getMaxHealth() * 0.2f) {
            float bonus = (float) Math.min(60.0, 10.0 + target.getMaxHealth() * 0.35);
            Fx.hit(l, p, target, bonus);
            Fx.sound(l, c, ModSounds.EXECUTION, 1.0f, 1.0f);
            Fx.part(l, ParticleTypes.CRIT, c, 25, 0.4, 0.5, 0.4, 0.4);
            Fx.part(l, Fx.dust(Fx.CRIMSON, 2.0f), c, 20, 0.4, 0.6, 0.4, 0);
            Fx.part(l, ParticleTypes.EXPLOSION, c, 1, 0, 0, 0, 0);
        }
    }

    // ------------------------------------------------------------------ actives
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel l) || !(player instanceof ServerPlayer p)) return InteractionResult.SUCCESS;
        if (p.isShiftKeyDown()) {
            int s = Cooldowns.cycle(p, WEAPON, NAMES.length);
            p.displayClientMessage(Component.literal("Ability: " + NAMES[s]), true);
            return InteractionResult.CONSUME;
        }
        int slot = Cooldowns.selected(p, WEAPON);
        if (!Cooldowns.ready(p, slot)) {
            p.displayClientMessage(Component.literal(NAMES[slot] + " recharging: "
                    + String.format("%.1fs", Cooldowns.remaining(p, slot) / 20.0)), true);
            return InteractionResult.CONSUME;
        }
        Cooldowns.start(p, slot, COOLDOWN[slot]);
        switch (slot) {
            case 0 -> reaperSlash(l, p);
            case 1 -> shadowDash(l, p);
            case 2 -> deathSpiral(l, p);
            default -> blackHole(l, p);
        }
        return InteractionResult.SUCCESS;
    }

    /** Reaper Slash: 150-degree crescent sweep, hits everything in front. */
    private static void reaperSlash(ServerLevel l, ServerPlayer p) {
        Vec3 dir = Fx.flat(p.getLookAngle());
        Vec3 origin = p.position().add(0, 0.9, 0);
        double mult = soulMult(p);
        Fx.sound(l, origin, ModSounds.REAPER_SLASH, 1.0f, 1.0f);
        Set<UUID> done = new HashSet<>();
        Tasks.each(6, i -> {
            if (!p.isAlive()) return true;
            double a = Math.toRadians(-75 + 150.0 * i / 5.0);
            Vec3 d = Fx.rotY(dir, a);
            for (double r = 1.2; r <= 5.6; r += 0.45) {
                Vec3 pt = origin.add(d.scale(r)).add(0, 0.25 * Math.sin(r), 0);
                Fx.part(l, Fx.dust(Fx.CRIMSON, 1.5f), pt, 1, 0.03, 0.03, 0.03, 0);
                if (((int) (r * 10)) % 2 == 0) Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, pt, 1, 0.02, 0.02, 0.02, 0.005);
                if (r > 4.4) Fx.part(l, Fx.dust(Fx.PURPLE, 1.1f), pt.add(0, 0.2, 0), 1, 0.05, 0.05, 0.05, 0);
            }
            Fx.part(l, ParticleTypes.SWEEP_ATTACK, origin.add(d.scale(4.6)), 1, 0, 0, 0, 0);
            Fx.part(l, ParticleTypes.LARGE_SMOKE, origin.add(d.scale(3.5)), 1, 0.1, 0.1, 0.1, 0.01);
            if (i == 2) {
                for (LivingEntity e : Fx.near(l, p, origin, 5.6)) {
                    Vec3 to = Fx.flat(Fx.mid(e).subtract(origin));
                    if (to.dot(dir) < 0.34 || !done.add(e.getUUID())) continue;
                    Fx.hit(l, p, e, (float) (Fx.atk(p) * 0.9 * mult));
                    Fx.launch(e, to.scale(0.6).add(0, 0.3, 0));
                    Fx.part(l, ParticleTypes.CRIT, Fx.mid(e), 12, 0.3, 0.4, 0.3, 0.3);
                }
            }
            return false;
        });
    }

    /** Shadow Dash: rapid dash that damages everything it passes through. */
    private static void shadowDash(ServerLevel l, ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 v = new Vec3(look.x, look.y * 0.35, look.z).normalize().scale(1.7);
        double mult = soulMult(p);
        Fx.sound(l, p.position(), ModSounds.REAPER_DASH, 1.0f, 1.0f);
        Set<UUID> done = new HashSet<>();
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 14, 4, false, false));
        Tasks.each(7, i -> {
            if (!p.isAlive()) return true;
            Fx.push(p, v);
            Vec3 pos = p.position().add(0, 1.0, 0);
            Fx.part(l, ParticleTypes.LARGE_SMOKE, pos, 6, 0.3, 0.5, 0.3, 0.02);
            Fx.part(l, Fx.dust(Fx.VOID, 2.2f), pos, 6, 0.3, 0.5, 0.3, 0);
            Fx.part(l, Fx.dust(Fx.PURPLE, 1.4f), pos, 4, 0.25, 0.45, 0.25, 0);
            Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, pos, 3, 0.2, 0.4, 0.2, 0.02);
            for (LivingEntity e : Fx.near(l, p, pos, 1.8)) {
                if (!done.add(e.getUUID())) continue;
                Fx.hit(l, p, e, (float) (Fx.atk(p) * 0.85 * mult));
                Fx.launch(e, v.scale(0.35).add(0, 0.35, 0));
                Fx.part(l, ParticleTypes.SWEEP_ATTACK, Fx.mid(e), 1, 0, 0, 0, 0);
                Fx.part(l, Fx.dust(Fx.CRIMSON, 1.6f), Fx.mid(e), 12, 0.3, 0.4, 0.3, 0);
            }
            if (i == 6) {
                Fx.push(p, v.scale(0.25));
                Fx.part(l, ParticleTypes.REVERSE_PORTAL, pos, 30, 0.4, 0.6, 0.4, 0.2);
            }
            return false;
        });
    }

    /** Death Spiral: whirling twin blades continuously shred nearby enemies. */
    private static void deathSpiral(ServerLevel l, ServerPlayer p) {
        double mult = soulMult(p);
        Fx.sound(l, p.position(), ModSounds.DEATH_SPIRAL, 1.0f, 1.0f);
        p.addEffect(new MobEffectInstance(MobEffects.RESISTANCE, 32, 1, false, false));
        Tasks.each(32, i -> {
            if (!p.isAlive()) return true;
            Vec3 c = p.position().add(0, 0.9, 0);
            double base = i * 0.75;
            for (int arm = 0; arm < 2; arm++) {
                double a0 = base + arm * Math.PI;
                for (double r = 1.0; r <= 3.8; r += 0.4) {
                    double a = a0 - r * 0.35; // curved blade trailing behind
                    Vec3 pt = c.add(Math.cos(a) * r, Math.sin(i * 0.4 + arm) * 0.15, Math.sin(a) * r);
                    Fx.part(l, Fx.dust(Fx.CRIMSON, 1.4f), pt, 1, 0.02, 0.02, 0.02, 0);
                    if (r > 3.0) Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, pt, 1, 0.02, 0.02, 0.02, 0.01);
                }
            }
            Fx.part(l, ParticleTypes.LARGE_SMOKE, c, 2, 1.2, 0.2, 1.2, 0.01);
            if (i % 3 == 0) {
                Fx.sound(l, c, ModSounds.REAPER_SLASH, 0.35f, 1.3f + (i % 6) * 0.03f);
                for (LivingEntity e : Fx.near(l, p, c, 4.0)) {
                    Fx.hit(l, p, e, (float) (Fx.atk(p) * 0.38 * mult));
                    Vec3 out = Fx.flat(Fx.mid(e).subtract(c));
                    Fx.launch(e, out.scale(0.35).add(0, 0.18, 0));
                    Fx.part(l, ParticleTypes.CRIT, Fx.mid(e), 5, 0.3, 0.4, 0.3, 0.2);
                }
            }
            return false;
        });
    }

    /** Black Hole: void pulls enemies in, then detonates in a wave of dark energy. */
    private static void blackHole(ServerLevel l, ServerPlayer p) {
        Vec3 center = p.getEyePosition().add(p.getLookAngle().scale(7.0));
        double mult = soulMult(p);
        Fx.sound(l, center, ModSounds.BLACK_HOLE_CHARGE, 1.6f, 1.0f);
        Tasks.each(60, i -> {
            if (!p.isAlive()) return true;
            double grow = Math.min(1.0, i / 20.0);
            // dark core + inward spiral
            Fx.part(l, Fx.dust(Fx.VOID, (float) (3.0 * grow + 0.5)), center, 10, 0.35 * grow, 0.35 * grow, 0.35 * grow, 0);
            Fx.part(l, ParticleTypes.SQUID_INK, center, 2, 0.3, 0.3, 0.3, 0.02);
            for (int k = 0; k < 6; k++) {
                double a = i * 0.45 + k * Math.PI / 3, r = 6.0 * (1 - (i % 20) / 20.0) + 0.6;
                Vec3 pt = center.add(Math.cos(a) * r, Math.sin(a * 2) * 0.8, Math.sin(a) * r);
                Fx.part(l, ParticleTypes.REVERSE_PORTAL, pt, 1, 0, 0, 0, 0);
                if (k % 2 == 0) Fx.part(l, Fx.dust(Fx.PURPLE, 1.2f), pt, 1, 0, 0, 0, 0);
            }
            if (i % 3 == 0) Fx.part(l, ParticleTypes.PORTAL, center, 12, 1.5, 1.5, 1.5, 0.5);
            for (LivingEntity e : Fx.near(l, p, center, 11.0)) {
                Vec3 to = center.subtract(Fx.mid(e));
                double dist = Math.max(0.5, to.length());
                Vec3 pull = to.normalize().scale(Math.min(0.75, 0.25 + 1.4 / dist));
                Fx.launch(e, e.getDeltaMovement().scale(0.5).add(pull));
                if (i % 10 == 0) Fx.hit(l, p, e, (float) (Fx.atk(p) * 0.2 * mult));
            }
            if (i == 59) {
                Fx.sound(l, center, ModSounds.BLACK_HOLE_EXPLODE, 2.0f, 1.0f);
                Fx.part(l, ParticleTypes.EXPLOSION_EMITTER, center, 1, 0, 0, 0, 0);
                Fx.part(l, ParticleTypes.REVERSE_PORTAL, center, 250, 0.5, 0.5, 0.5, 1.2);
                Fx.part(l, Fx.dust(Fx.PURPLE, 2.5f), center, 100, 2.5, 2.5, 2.5, 0);
                Fx.part(l, Fx.dust(Fx.CRIMSON, 2.0f), center, 60, 2.0, 2.0, 2.0, 0);
                Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, center, 80, 2.0, 2.0, 2.0, 0.25);
                for (int ring = 1; ring <= 4; ring++) {
                    int rr = ring;
                    Tasks.later(ring, () -> Fx.ring(l, Fx.dust(Fx.PURPLE, 2.0f), center, rr * 2.2, 36, 0));
                }
                for (LivingEntity e : Fx.near(l, p, center, 9.0)) {
                    Vec3 out = Fx.mid(e).subtract(center).normalize();
                    Fx.hit(l, p, e, (float) (Fx.atk(p) * 2.2 * mult));
                    Fx.launch(e, out.scale(1.5).add(0, 0.7, 0));
                    e.addEffect(new MobEffectInstance(MobEffects.WITHER, 80, 1));
                }
            }
            return false;
        });
    }
}
