# Legendary Arsenal (Fabric, Minecraft 26.3)

Build:  `gradle wrapper` (once, needs Gradle 9.5.1) then `./gradlew build`  ->  build/libs/legendary-arsenal-1.0.0.jar
Run in dev:  `./gradlew runClient`
Install:  drop the jar + Fabric API 0.160.7+26.3 into your mods folder (Fabric Loader 0.19.5+, Java 25).

Controls (both weapons): Shift+Right-Click = cycle ability, Right-Click = cast, normal attack = passives.
Regenerate art/audio: python3 tools/gen_textures.py ; python3 tools/gen_sounds.py  (needs Pillow, numpy, scipy, ffmpeg)
