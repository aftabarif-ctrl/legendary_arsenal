package com.legendary.arsenal;

import java.util.ArrayList;
import java.util.List;
import java.util.function.IntPredicate;

/** Tiny tick scheduler used to choreograph multi-tick ability animations. */
public final class Tasks {
    public interface Task { boolean tick(); } // return true when finished

    private static final List<Task> ACTIVE = new ArrayList<>();
    private static final List<Task> PENDING = new ArrayList<>();

    public static void add(Task t) { PENDING.add(t); }

    /** Runs body(i) for i = 0..ticks-1, one per tick. Body may return true to stop early. */
    public static void each(int ticks, IntPredicate body) {
        int[] i = {0};
        add(() -> body.test(i[0]++) || i[0] >= ticks);
    }

    /** Runs body every tick until it returns true. */
    public static void until(IntPredicate body) {
        int[] i = {0};
        add(() -> body.test(i[0]++));
    }

    public static void later(int delay, Runnable r) {
        int[] i = {0};
        add(() -> { if (i[0]++ >= delay) { r.run(); return true; } return false; });
    }

    public static void tick() {
        ACTIVE.addAll(PENDING);
        PENDING.clear();
        ACTIVE.removeIf(t -> {
            try { return t.tick(); }
            catch (Exception e) { LegendaryArsenal.LOGGER.error("Ability task failed", e); return true; }
        });
    }

    public static void clear() { ACTIVE.clear(); PENDING.clear(); }
    private Tasks() {}
}
