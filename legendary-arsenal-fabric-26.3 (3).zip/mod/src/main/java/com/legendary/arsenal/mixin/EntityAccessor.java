package com.legendary.arsenal.mixin;

import net.minecraft.world.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Lets Fx reset the target's invulnerability frames so multi-hit abilities always register. */
@Mixin(Entity.class)
public interface EntityAccessor {
    @Accessor("invulnerableTime")
    void setInvulnerableTime(int ticks);
}
