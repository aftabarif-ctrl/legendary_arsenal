package com.legendary.arsenal;

import net.minecraft.core.Registry;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.Identifier;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.entity.EquipmentSlotGroup;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.component.ItemAttributeModifiers;

public final class ModItems {
    private static final AttributeModifier.Operation ADD = AttributeModifier.Operation.ADD_VALUE;

    // Total damage 10 (1 base + 9), 1.2 attacks/s, +1.5 reach
    public static final Item ECLIPSE_REAPER = register("eclipse_reaper", key -> new EclipseReaperItem(
            base(key).attributes(ItemAttributeModifiers.builder()
                    .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 9.0, ADD), EquipmentSlotGroup.MAINHAND)
                    .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -2.8, ADD), EquipmentSlotGroup.MAINHAND)
                    .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                            Identifier.fromNamespaceAndPath(LegendaryArsenal.MOD_ID, "reaper_reach"), 1.5, ADD), EquipmentSlotGroup.MAINHAND)
                    .build())));

    // Total damage 4, 3.4 attacks/s (very fast combo punches), +0.5 reach
    public static final Item TITANBREAKER_GAUNTLETS = register("titanbreaker_gauntlets", key -> new TitanbreakerGauntletsItem(
            base(key).attributes(ItemAttributeModifiers.builder()
                    .add(Attributes.ATTACK_DAMAGE, new AttributeModifier(Item.BASE_ATTACK_DAMAGE_ID, 3.0, ADD), EquipmentSlotGroup.MAINHAND)
                    .add(Attributes.ATTACK_SPEED, new AttributeModifier(Item.BASE_ATTACK_SPEED_ID, -0.6, ADD), EquipmentSlotGroup.MAINHAND)
                    .add(Attributes.ENTITY_INTERACTION_RANGE, new AttributeModifier(
                            Identifier.fromNamespaceAndPath(LegendaryArsenal.MOD_ID, "gauntlet_reach"), 0.5, ADD), EquipmentSlotGroup.MAINHAND)
                    .build())));

    private static Item.Properties base(ResourceKey<Item> key) {
        return new Item.Properties().setId(key).stacksTo(1).rarity(Rarity.EPIC)
                .component(DataComponents.ENCHANTMENT_GLINT_OVERRIDE, true);
    }

    private static Item register(String name, java.util.function.Function<ResourceKey<Item>, Item> factory) {
        ResourceKey<Item> key = ResourceKey.create(Registries.ITEM, Identifier.fromNamespaceAndPath(LegendaryArsenal.MOD_ID, name));
        return Registry.register(BuiltInRegistries.ITEM, key, factory.apply(key));
    }

    public static void init() {}
    private ModItems() {}
}
