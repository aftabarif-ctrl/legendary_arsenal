package com.legendary.arsenal;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import net.minecraft.server.level.ServerPlayer;

/** Per-player ability cooldowns (server game ticks) and selected-ability memory. */
public final class Cooldowns {
    private static final Map<UUID, long[]> CD = new HashMap<>();
    private static final Map<UUID, int[]> SEL = new HashMap<>();

    public static long now(ServerPlayer p) { return p.level().getGameTime(); }

    public static long remaining(ServerPlayer p, int slot) {
        long[] a = CD.get(p.getUUID());
        return a == null ? 0 : Math.max(0, a[slot] - now(p));
    }
    public static boolean ready(ServerPlayer p, int slot) { return remaining(p, slot) == 0; }
    public static void start(ServerPlayer p, int slot, int ticks) {
        CD.computeIfAbsent(p.getUUID(), k -> new long[16])[slot] = now(p) + ticks;
    }
    public static int selected(ServerPlayer p, int weapon) {
        return SEL.computeIfAbsent(p.getUUID(), k -> new int[4])[weapon];
    }
    public static int cycle(ServerPlayer p, int weapon, int count) {
        int[] s = SEL.computeIfAbsent(p.getUUID(), k -> new int[4]);
        s[weapon] = (s[weapon] + 1) % count;
        return s[weapon];
    }
    private Cooldowns() {}
}
