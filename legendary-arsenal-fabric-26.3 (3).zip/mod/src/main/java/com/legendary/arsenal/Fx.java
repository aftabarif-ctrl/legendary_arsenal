package com.legendary.arsenal;

import java.util.ArrayList;
import java.util.List;
import com.legendary.arsenal.mixin.EntityAccessor;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetActionBarTextPacket;
import net.minecraft.network.protocol.game.ClientboundSetEntityMotionPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.TamableAnimal;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

/** Shared helpers: particles, sounds, targeting, damage and knockback. */
public final class Fx {
    public static final int CRIMSON = 0xE0143C, PURPLE = 0x9B30FF, VOID = 0x0A0610,
                            BLUE = 0x3AB8FF, GOLD = 0xFFD36B, WHITE = 0xF4F8FF;

    public static ParticleOptions dust(int rgb, float size) { return new DustParticleOptions(rgb, size); }

    public static void sound(ServerLevel l, Vec3 p, SoundEvent s, float vol, float pitch) {
        l.playSound(null, p.x, p.y, p.z, s, SoundSource.PLAYERS, vol, pitch);
    }
    public static void part(ServerLevel l, ParticleOptions o, Vec3 p, int n, double dx, double dy, double dz, double speed) {
        l.sendParticles(o, p.x, p.y, p.z, n, dx, dy, dz, speed);
    }
    public static Vec3 flat(Vec3 v) {
        Vec3 f = new Vec3(v.x, 0, v.z);
        return f.lengthSqr() < 1.0E-4 ? new Vec3(0, 0, 1) : f.normalize();
    }
    public static Vec3 rotY(Vec3 v, double a) {
        double c = Math.cos(a), s = Math.sin(a);
        return new Vec3(v.x * c - v.z * s, v.y, v.x * s + v.z * c);
    }
    public static Vec3 mid(LivingEntity e) { return e.position().add(0, e.getBbHeight() * 0.5, 0); }

    public static boolean valid(ServerPlayer p, LivingEntity e) {
        if (e == p || !e.isAlive() || e.isSpectator() || e instanceof ArmorStand || e instanceof Player) return false;
        return !(e instanceof TamableAnimal t && t.isOwnedBy(p));
    }

    public static List<LivingEntity> near(ServerLevel l, ServerPlayer p, Vec3 c, double r) {
        AABB box = new AABB(c.x - r, c.y - r, c.z - r, c.x + r, c.y + r, c.z + r);
        List<LivingEntity> out = new ArrayList<>();
        for (LivingEntity e : l.getEntitiesOfClass(LivingEntity.class, box)) {
            if (valid(p, e) && mid(e).distanceTo(c) <= r + e.getBbWidth() * 0.5) out.add(e);
        }
        return out;
    }

    /** Damage that bypasses invulnerability frames so multi-hit abilities always register. */
    public static void hit(ServerLevel l, ServerPlayer p, LivingEntity t, float amount) {
        ((EntityAccessor) t).setInvulnerableTime(0);
        t.hurtServer(l, l.damageSources().playerAttack(p), amount);
    }
    public static void launch(LivingEntity e, Vec3 v) {
        e.setDeltaMovement(v);
        if (e instanceof ServerPlayer sp) sp.connection.send(new ClientboundSetEntityMotionPacket(sp));
    }
    public static void push(ServerPlayer p, Vec3 v) {
        p.setDeltaMovement(v);
        p.connection.send(new ClientboundSetEntityMotionPacket(p));
        p.resetFallDistance();
    }
    public static double atk(ServerPlayer p) {
        return p.getAttributeValue(net.minecraft.world.entity.ai.attributes.Attributes.ATTACK_DAMAGE);
    }

    public static void ring(ServerLevel l, ParticleOptions o, Vec3 c, double r, int n, double yOff) {
        for (int i = 0; i < n; i++) {
            double a = Math.PI * 2 * i / n;
            part(l, o, c.add(Math.cos(a) * r, yOff, Math.sin(a) * r), 1, 0, 0, 0, 0);
        }
    }
    public static void bar(ServerPlayer p, String text) {
        p.connection.send(new ClientboundSetActionBarTextPacket(Component.literal(text)));
    }
    /** True while the player's attack-cooldown meter is refilling, i.e. just swung. */
    public static boolean swung(ServerPlayer p) { return p.getAttackStrengthScale(0.0f) < 0.95f; }
    private Fx() {}
}
