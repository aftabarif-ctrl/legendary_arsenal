package com.legendary.arsenal;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.creativetab.v1.CreativeModeTabEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.entity.event.v1.ServerLivingEntityEvents;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.CreativeModeTabs;
import net.minecraft.world.phys.Vec3;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LegendaryArsenal implements ModInitializer {
    public static final String MOD_ID = "legendary_arsenal";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitialize() {
        ModSounds.init();
        ModItems.init();

        CreativeModeTabEvents.modifyOutputEvent(CreativeModeTabs.COMBAT).register(out -> {
            out.accept(ModItems.ECLIPSE_REAPER);
            out.accept(ModItems.TITANBREAKER_GAUNTLETS);
        });

        // Soul Harvest: any kill by a Reaper wielder collects a soul
        ServerLivingEntityEvents.AFTER_DEATH.register((victim, source) -> {
            if (source.getEntity() instanceof ServerPlayer p && p.getMainHandItem().is(ModItems.ECLIPSE_REAPER)) {
                EclipseReaperItem.onKill(p, victim);
            }
        });

        ServerTickEvents.END_SERVER_TICK.register(server -> {
            Tasks.tick();
            for (ServerPlayer p : server.getPlayerList().getPlayers()) tickPlayer(p);
        });
        ServerLifecycleEvents.SERVER_STOPPING.register(s -> Tasks.clear());
    }

    private static void tickPlayer(ServerPlayer p) {
        if (p.isSpectator() || !(p.level() instanceof ServerLevel l)) return;
        long t = l.getGameTime();
        boolean reaper = p.getMainHandItem().is(ModItems.ECLIPSE_REAPER);
        boolean gaunt = p.getMainHandItem().is(ModItems.TITANBREAKER_GAUNTLETS)
                || p.getOffhandItem().is(ModItems.TITANBREAKER_GAUNTLETS);
        if (!reaper && !gaunt) return;
        Vec3 look = p.getLookAngle();
        Vec3 right = Fx.rotY(Fx.flat(look), -Math.PI / 2);

        if (reaper) {
            int souls = EclipseReaperItem.souls(p);
            // floating soul fragments orbiting the blade
            if (t % 2 == 0) {
                int n = 2 + souls / 2;
                Vec3 c = p.position().add(0, 1.3, 0).add(right.scale(0.6)).add(Fx.flat(look).scale(0.5));
                for (int i = 0; i < n; i++) {
                    double a = t * 0.18 + i * Math.PI * 2 / n;
                    Vec3 pt = c.add(Math.cos(a) * 0.9, Math.sin(a * 1.3) * 0.5, Math.sin(a) * 0.9);
                    Fx.part(l, ParticleTypes.SOUL_FIRE_FLAME, pt, 1, 0, 0, 0, 0);
                }
                Fx.part(l, ParticleTypes.SMOKE, c.add(0, 0.3, 0), 1, 0.5, 0.4, 0.5, 0.005);
            }
            // blade trail on swings
            if (Fx.swung(p)) {
                Vec3 f = Fx.flat(look);
                for (int i = 0; i < 6; i++) {
                    double a = Math.toRadians(-60 + 120 * p.getAttackStrengthScale(0.0f)) + i * 0.08;
                    Vec3 d = Fx.rotY(f, a);
                    Vec3 pt = p.position().add(0, 1.0, 0).add(d.scale(1.6 + i * 0.4));
                    Fx.part(l, Fx.dust(Fx.CRIMSON, 1.3f), pt, 1, 0, 0, 0, 0);
                    Fx.part(l, Fx.dust(Fx.PURPLE, 1.0f), pt.add(0, 0.2, 0), 1, 0, 0, 0, 0);
                }
            }
            if (t % 5 == 0) bar(p, "Eclipse Reaper | " + EclipseReaperItem.NAMES[Cooldowns.selected(p, 0)]
                    + status(Cooldowns.remaining(p, Cooldowns.selected(p, 0))) + " | Souls " + souls + "/10");
        }

        if (gaunt) {
            // punch trails on swings
            if (Fx.swung(p)) {
                for (int i = 0; i < 4; i++) {
                    Vec3 pt = p.getEyePosition().add(look.scale(0.9 + i * 0.35)).add(0, -0.45, 0)
                            .add(right.scale(((l.getGameTime() & 1) == 0 ? 0.35 : -0.35)));
                    Fx.part(l, Fx.dust(Fx.BLUE, 1.2f), pt, 1, 0, 0, 0, 0);
                    Fx.part(l, ParticleTypes.ELECTRIC_SPARK, pt, 1, 0.05, 0.05, 0.05, 0.05);
                }
            }
            if (t % 8 == 0) // idle glow on both fists
                for (int s = -1; s <= 1; s += 2)
                    Fx.part(l, Fx.dust(Fx.BLUE, 0.9f), p.position().add(0, 1.0, 0).add(right.scale(0.55 * s)).add(Fx.flat(look).scale(0.4)), 1, 0.03, 0.03, 0.03, 0);
            if (t % 5 == 0 && !p.getMainHandItem().is(ModItems.ECLIPSE_REAPER)) {
                int sel = Cooldowns.selected(p, 1);
                int combo = TitanbreakerGauntletsItem.combo(p);
                bar(p, "Titanbreaker | " + TitanbreakerGauntletsItem.NAMES[sel]
                        + status(Cooldowns.remaining(p, TitanbreakerGauntletsItem.CD_BASE + sel))
                        + " | Combo x" + combo
                        + (TitanbreakerGauntletsItem.adrenaline(p) ? " | ADRENALINE " + TitanbreakerGauntletsItem.adrenalineLeft(p) / 20 + "s" : ""));
            }
        }
    }

    private static String status(long remainingTicks) {
        return remainingTicks == 0 ? " [READY]" : String.format(" [%.1fs]", remainingTicks / 20.0);
    }
    private static void bar(Player p, String text) { Fx.bar((ServerPlayer) p, text); }
}
