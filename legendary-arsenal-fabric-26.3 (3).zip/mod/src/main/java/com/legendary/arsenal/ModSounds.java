package com.legendary.arsenal;

import net.minecraft.core.Registry;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.resources.Identifier;
import net.minecraft.sounds.SoundEvent;

public final class ModSounds {
    public static final SoundEvent REAPER_SLASH = reg("reaper_slash");
    public static final SoundEvent REAPER_DASH = reg("reaper_dash");
    public static final SoundEvent SOUL_HARVEST = reg("soul_harvest");
    public static final SoundEvent DEATH_SPIRAL = reg("death_spiral");
    public static final SoundEvent BLACK_HOLE_CHARGE = reg("black_hole_charge");
    public static final SoundEvent BLACK_HOLE_EXPLODE = reg("black_hole_explode");
    public static final SoundEvent EXECUTION = reg("execution");
    public static final SoundEvent GAUNTLET_PUNCH = reg("gauntlet_punch");
    public static final SoundEvent ROCKET_PUNCH = reg("rocket_punch");
    public static final SoundEvent GROUND_SLAM = reg("ground_slam");
    public static final SoundEvent GRAVITY_PULL = reg("gravity_pull");
    public static final SoundEvent ADRENALINE = reg("adrenaline");
    public static final SoundEvent WORLD_BREAKER = reg("world_breaker");

    private static SoundEvent reg(String name) {
        Identifier id = Identifier.fromNamespaceAndPath(LegendaryArsenal.MOD_ID, name);
        return Registry.register(BuiltInRegistries.SOUND_EVENT, id, SoundEvent.createVariableRangeEvent(id));
    }

    public static void init() {}
    private ModSounds() {}
}
