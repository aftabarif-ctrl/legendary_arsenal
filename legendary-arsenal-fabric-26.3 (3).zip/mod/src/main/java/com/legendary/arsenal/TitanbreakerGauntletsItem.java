package com.legendary.arsenal;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

/**
 * Titanbreaker Gauntlets. Shift+Right-Click cycles, Right-Click casts:
 *   0 Rocket Punch, 1 Ground Slam, 2 Gravity Smash, 3 Adrenaline Mode, 4 World Breaker (ultimate)
 * Passive: Combo Fury - chain hits within 1.5s for rising damage and faster, heavier punches.
 */
public class TitanbreakerGauntletsItem extends Item {
    public static final String[] NAMES = {"Rocket Punch", "Ground Slam", "Gravity Smash", "Adrenaline Mode", "World Breaker (Ultimate)"};
    public static final int[] COOLDOWN = {100, 140, 200, 600, 1100};
    static final int WEAPON = 1, CD_BASE = 4; // cooldown slots 4..8 (Reaper uses 0..3)

    private static final class Combo { int count; long last; }
    private static final Map<UUID, Combo> COMBOS = new HashMap<>();
    private static final Map<UUID, Long> ADRENALINE = new HashMap<>();
    private static final int COMBO_WINDOW = 30, MAX_COMBO = 12;

    public static int combo(ServerPlayer p) {
        Combo c = COMBOS.get(p.getUUID());
        return c == null || Cooldowns.now(p) - c.last > COMBO_WINDOW ? 0 : c.count;
    }
    public static boolean adrenaline(ServerPlayer p) {
        Long e = ADRENALINE.get(p.getUUID());
        return e != null && Cooldowns.now(p) < e;
    }
    public static long adrenalineLeft(ServerPlayer p) {
        Long e = ADRENALINE.get(p.getUUID());
        return e == null ? 0 : Math.max(0, e - Cooldowns.now(p));
    }

    public TitanbreakerGauntletsItem(Properties props) { super(props); }

    // ------------------------------------------------------------------ passive: Combo Fury
    @Override
    public void hurtEnemy(ItemStack stack, LivingEntity target, LivingEntity attacker) {
        if (!(attacker instanceof ServerPlayer p) || !(p.level() instanceof ServerLevel l)) return;
        long now = Cooldowns.now(p);
        Combo c = COMBOS.computeIfAbsent(p.getUUID(), k -> new Combo());
        c.count = (now - c.last > COMBO_WINDOW) ? 1 : Math.min(MAX_COMBO, c.count + 1);
        c.last = now;
        double mult = adrenaline(p) ? 1.6 : 1.0;
        float bonus = (float) (0.55 * c.count * mult);
        if (bonus > 0.1f) Fx.hit(l, p, target, bonus);
        Vec3 mid = Fx.mid(target);
        Fx.sound(l, mid, ModSounds.GAUNTLET_PUNCH, 0.8f, 0.8f + c.count * 0.05f);
        Fx.part(l, ParticleTypes.CRIT, mid, 6 + c.count, 0.3, 0.4, 0.3, 0.3);
        Fx.part(l, Fx.dust(Fx.BLUE, 1.4f), mid, 8, 0.3, 0.4, 0.3, 0);
        Fx.part(l, ParticleTypes.ELECTRIC_SPARK, mid, 4 + c.count / 2, 0.3, 0.4, 0.3, 0.4);
        if (c.count % 4 == 0) { // finisher every 4th hit
            Vec3 dir = Fx.flat(p.getLookAngle());
            Fx.launch(target, dir.scale(0.9).add(0, 0.35, 0));
            Fx.part(l, ParticleTypes.EXPLOSION, mid, 1, 0, 0, 0, 0);
            Fx.part(l, Fx.dust(Fx.GOLD, 1.8f), mid, 14, 0.4, 0.5, 0.4, 0);
            Fx.sound(l, mid, ModSounds.GROUND_SLAM, 0.45f, 1.7f);
        }
    }

    // ------------------------------------------------------------------ actives
    @Override
    public InteractionResult use(Level level, Player player, InteractionHand hand) {
        if (!(level instanceof ServerLevel l) || !(player instanceof ServerPlayer p)) return InteractionResult.SUCCESS;
        if (p.isShiftKeyDown()) {
            int s = Cooldowns.cycle(p, WEAPON, NAMES.length);
            Fx.bar(p, "Ability: " + NAMES[s]);
            return InteractionResult.CONSUME;
        }
        int sel = Cooldowns.selected(p, WEAPON), slot = CD_BASE + sel;
        if (!Cooldowns.ready(p, slot)) {
            Fx.bar(p, NAMES[sel] + " recharging: "
                    + String.format("%.1fs", Cooldowns.remaining(p, slot) / 20.0));
            return InteractionResult.CONSUME;
        }
        Cooldowns.start(p, slot, COOLDOWN[sel]);
        switch (sel) {
            case 0 -> rocketPunch(l, p);
            case 1 -> groundSlam(l, p);
            case 2 -> gravitySmash(l, p);
            case 3 -> adrenalineMode(l, p);
            default -> worldBreaker(l, p);
        }
        return InteractionResult.SUCCESS;
    }

    private static float dmg(ServerPlayer p, double factor) {
        return (float) (Fx.atk(p) * factor * (adrenaline(p) ? 1.6 : 1.0));
    }

    /** Rocket Punch: dash forward with a shoulder-high punch that launches the first thing it hits. */
    private static void rocketPunch(ServerLevel l, ServerPlayer p) {
        Vec3 look = p.getLookAngle();
        Vec3 v = new Vec3(look.x, look.y * 0.3, look.z).normalize().scale(1.9);
        Fx.sound(l, p.position(), ModSounds.ROCKET_PUNCH, 1.0f, 1.0f);
        Set<UUID> done = new HashSet<>();
        Tasks.each(9, i -> {
            if (!p.isAlive()) return true;
            Fx.push(p, v);
            Vec3 pos = p.position().add(0, 1.1, 0);
            Vec3 fist = pos.add(v.normalize().scale(1.0));
            Fx.part(l, Fx.dust(Fx.BLUE, 1.8f), fist, 6, 0.15, 0.15, 0.15, 0);
            Fx.part(l, ParticleTypes.ELECTRIC_SPARK, pos, 5, 0.3, 0.3, 0.3, 0.3);
            Fx.part(l, ParticleTypes.CLOUD, pos, 2, 0.2, 0.2, 0.2, 0.02);
            Fx.part(l, Fx.dust(Fx.GOLD, 1.2f), pos.subtract(v.normalize().scale(0.8)), 3, 0.2, 0.2, 0.2, 0);
            boolean hitAny = false;
            for (LivingEntity e : Fx.near(l, p, fist, 1.7)) {
                if (!done.add(e.getUUID())) continue;
                hitAny = true;
                Fx.hit(l, p, e, dmg(p, 2.0));
                Fx.launch(e, v.normalize().scale(2.1).add(0, 0.55, 0));
                Fx.part(l, ParticleTypes.EXPLOSION, Fx.mid(e), 1, 0, 0, 0, 0);
                Fx.part(l, ParticleTypes.END_ROD, Fx.mid(e), 25, 0.5, 0.5, 0.5, 0.3);
                Fx.sound(l, Fx.mid(e), ModSounds.GAUNTLET_PUNCH, 1.2f, 0.6f);
            }
            if (hitAny) { Fx.push(p, v.scale(0.1)); return true; }
            return false;
        });
    }

    /** Ground Slam: leap, then crash down and send a shockwave. */
    private static void groundSlam(ServerLevel l, ServerPlayer p) {
        Vec3 flat = Fx.flat(p.getLookAngle());
        Fx.push(p, flat.scale(0.35).add(0, 1.0, 0));
        Fx.sound(l, p.position(), ModSounds.ROCKET_PUNCH, 0.7f, 1.4f);
        Tasks.until(i -> {
            if (!p.isAlive()) return true;
            p.resetFallDistance();
            Fx.part(l, ParticleTypes.CLOUD, p.position(), 2, 0.2, 0.1, 0.2, 0.02);
            Fx.part(l, Fx.dust(Fx.BLUE, 1.2f), p.position().add(0, 1, 0), 2, 0.3, 0.4, 0.3, 0);
            if (i == 7) Fx.push(p, new Vec3(flat.x * 0.2, -2.4, flat.z * 0.2));
            if (i > 8 && (p.onGround() || i > 40)) {
                shockwave(l, p, p.position(), 7.5, dmg(p, 2.2), 0.9, 0.85);
                return true;
            }
            return i > 45;
        });
    }

    /** Gravity Smash: drag enemies in, then land a massive punch. */
    private static void gravitySmash(ServerLevel l, ServerPlayer p) {
        Fx.sound(l, p.position(), ModSounds.GRAVITY_PULL, 1.3f, 1.0f);
        Tasks.each(18, i -> {
            if (!p.isAlive()) return true;
            Vec3 c = p.position().add(0, 1.0, 0);
            Vec3 front = c.add(Fx.flat(p.getLookAngle()).scale(1.6));
            for (int k = 0; k < 8; k++) {
                double a = i * 0.5 + k * Math.PI / 4, r = 8.0 * (1 - i / 18.0) + 1.0;
                Fx.part(l, Fx.dust(Fx.BLUE, 1.3f), c.add(Math.cos(a) * r, Math.sin(a * 1.5) * 0.6, Math.sin(a) * r), 1, 0, 0, 0, 0);
            }
            Fx.part(l, ParticleTypes.REVERSE_PORTAL, c, 6, 2.5, 1.0, 2.5, 0.1);
            for (LivingEntity e : Fx.near(l, p, c, 10.0)) {
                Vec3 to = front.subtract(Fx.mid(e));
                if (to.length() < 1.2) { Fx.launch(e, Vec3.ZERO); continue; }
                Fx.launch(e, to.normalize().scale(Math.min(0.9, 0.3 + to.length() * 0.08)));
                e.addEffect(new MobEffectInstance(MobEffects.SLOWNESS, 6, 3, false, false));
            }
            if (i == 17) {
                Vec3 dir = Fx.flat(p.getLookAngle());
                Vec3 impact = c.add(dir.scale(1.8));
                Fx.sound(l, impact, ModSounds.GROUND_SLAM, 1.4f, 1.1f);
                Fx.part(l, ParticleTypes.EXPLOSION_EMITTER, impact, 1, 0, 0, 0, 0);
                Fx.part(l, ParticleTypes.END_ROD, impact, 25, 0.5, 0.5, 0.5, 0.3);
                Fx.part(l, Fx.dust(Fx.GOLD, 2.0f), impact, 40, 1.0, 1.0, 1.0, 0);
                Fx.part(l, ParticleTypes.ELECTRIC_SPARK, impact, 60, 1.2, 1.2, 1.2, 0.6);
                for (LivingEntity e : Fx.near(l, p, impact, 4.0)) {
                    Fx.hit(l, p, e, dmg(p, 3.2));
                    Fx.launch(e, Fx.mid(e).subtract(c).normalize().scale(1.3).add(0, 0.9, 0));
                }
            }
            return false;
        });
    }

    /** Adrenaline Mode: 10 seconds of overdrive. */
    private static void adrenalineMode(ServerLevel l, ServerPlayer p) {
        long dur = 200;
        ADRENALINE.put(p.getUUID(), Cooldowns.now(p) + dur);
        p.addEffect(new MobEffectInstance(MobEffects.SPEED, (int) dur, 2, false, true));
        p.addEffect(new MobEffectInstance(MobEffects.HASTE, (int) dur, 3, false, true)); // faster swings
        p.addEffect(new MobEffectInstance(MobEffects.STRENGTH, (int) dur, 0, false, true));
        Fx.sound(l, p.position(), ModSounds.ADRENALINE, 1.2f, 1.0f);
        Fx.part(l, ParticleTypes.END_ROD, p.position().add(0, 1, 0), 25, 0.5, 0.5, 0.5, 0.3);
        Fx.ring(l, Fx.dust(Fx.BLUE, 1.6f), p.position(), 1.8, 28, 0.1);
        Tasks.until(i -> {
            if (!p.isAlive() || !adrenaline(p)) return true;
            Vec3 c = p.position().add(0, 1, 0);
            double a = i * 0.5;
            Fx.part(l, Fx.dust(Fx.BLUE, 1.1f), c.add(Math.cos(a) * 0.9, Math.sin(i * 0.3) * 0.7, Math.sin(a) * 0.9), 1, 0, 0, 0, 0);
            Fx.part(l, ParticleTypes.ELECTRIC_SPARK, c, 1, 0.5, 0.8, 0.5, 0.1);
            return false;
        });
    }

    /** World Breaker: leap up, slam both fists down, three escalating shockwaves. */
    private static void worldBreaker(ServerLevel l, ServerPlayer p) {
        Fx.push(p, new Vec3(0, 1.3, 0));
        Fx.sound(l, p.position(), ModSounds.ROCKET_PUNCH, 1.0f, 0.7f);
        Tasks.until(i -> {
            if (!p.isAlive()) return true;
            p.resetFallDistance();
            Vec3 c = p.position().add(0, 1, 0);
            Fx.part(l, Fx.dust(Fx.GOLD, 1.6f), c, 4, 0.5, 0.6, 0.5, 0);
            Fx.part(l, ParticleTypes.ELECTRIC_SPARK, c, 6, 0.6, 0.6, 0.6, 0.3);
            if (i == 10) {
                Fx.push(p, new Vec3(0, -3.0, 0));
                Fx.sound(l, p.position(), ModSounds.GRAVITY_PULL, 0.8f, 1.5f);
            }
            if (i > 11 && (p.onGround() || i > 50)) {
                Vec3 at = p.position();
                Fx.sound(l, at, ModSounds.WORLD_BREAKER, 2.2f, 1.0f);
                Fx.part(l, ParticleTypes.EXPLOSION_EMITTER, at, 1, 0, 0, 0, 0);
                Fx.part(l, ParticleTypes.END_ROD, at.add(0, 1, 0), 25, 0.5, 0.5, 0.5, 0.3);
                // two fists: spark bursts either side of the player
                Vec3 side = Fx.rotY(Fx.flat(p.getLookAngle()), Math.PI / 2).scale(0.9);
                for (Vec3 fist : new Vec3[]{at.add(side), at.subtract(side)}) {
                    Fx.part(l, ParticleTypes.EXPLOSION, fist, 1, 0, 0, 0, 0);
                    Fx.part(l, Fx.dust(Fx.BLUE, 2.2f), fist, 20, 0.4, 0.2, 0.4, 0);
                }
                double[] radius = {7.0, 11.0, 15.0};
                double[] factor = {2.2, 1.9, 1.6};
                for (int w = 0; w < 3; w++) {
                    int ww = w;
                    Tasks.later(w * 6, () -> {
                        if (ww > 0) Fx.sound(l, at, ModSounds.GROUND_SLAM, 1.6f, 0.7f + ww * 0.15f);
                        shockwave(l, p, at, radius[ww], dmg(p, factor[ww]), 1.3, 1.5);
                    });
                }
                // radial fissures
                BlockState below = l.getBlockState(BlockPos.containing(at).below());
                for (int d = 0; d < 12; d++) {
                    Vec3 dir = new Vec3(Math.cos(d * Math.PI / 6), 0, Math.sin(d * Math.PI / 6));
                    int dd = d;
                    Tasks.each(10, s -> {
                        Vec3 pt = at.add(dir.scale(1.0 + s * 1.2));
                        Fx.part(l, ParticleTypes.LAVA, pt, 1, 0.1, 0.1, 0.1, 0);
                        Fx.part(l, ParticleTypes.CRIT, pt, 2, 0.1, 0.2, 0.1, 0.1);
                        if (!below.isAir()) Fx.part(l, new BlockParticleOption(ParticleTypes.BLOCK, below), pt, 8, 0.3, 0.2, 0.3, 0.1);
                        return false;
                    });
                }
                return true;
            }
            return i > 55;
        });
    }

    /** Expanding ground shockwave: ring particles + damage + launch for everything inside. */
    private static void shockwave(ServerLevel l, ServerPlayer p, Vec3 origin, double radius, float damage, double upward, double outward) {
        Fx.sound(l, origin, ModSounds.GROUND_SLAM, 1.5f, 1.0f);
        Fx.part(l, ParticleTypes.EXPLOSION, origin, 1, 0, 0, 0, 0);
        BlockState below = l.getBlockState(BlockPos.containing(origin).below());
        Set<UUID> done = new HashSet<>();
        int steps = 8;
        Tasks.each(steps, i -> {
            double r = radius * (i + 1) / steps;
            Fx.ring(l, ParticleTypes.CLOUD, origin, r, (int) (14 + r * 5), 0.15);
            Fx.ring(l, Fx.dust(Fx.BLUE, 1.6f), origin, r, (int) (14 + r * 5), 0.3);
            Fx.ring(l, ParticleTypes.ELECTRIC_SPARK, origin, r, (int) (8 + r * 3), 0.5);
            if (!below.isAir()) {
                for (int k = 0; k < (int) (6 + r * 2); k++) {
                    double a = Math.random() * Math.PI * 2;
                    Fx.part(l, new BlockParticleOption(ParticleTypes.BLOCK, below),
                            origin.add(Math.cos(a) * r, 0.2, Math.sin(a) * r), 4, 0.2, 0.3, 0.2, 0.15);
                }
            }
            for (LivingEntity e : Fx.near(l, p, origin, r + 0.8)) {
                if (!done.add(e.getUUID())) continue;
                Vec3 out = Fx.flat(Fx.mid(e).subtract(origin));
                Fx.hit(l, p, e, damage);
                Fx.launch(e, out.scale(outward).add(0, upward, 0));
            }
            return false;
        });
    }
}
