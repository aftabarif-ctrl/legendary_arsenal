"""Synthesizes the weapon sound effects (mono .ogg) with numpy + ffmpeg."""
import numpy as np, subprocess, os
from scipy.signal import butter, lfilter
from scipy.io import wavfile
SR=44100
OUT="../src/main/resources/assets/legendary_arsenal/sounds"
os.makedirs(OUT,exist_ok=True)
rng=np.random.default_rng(7)
def T(d): return np.linspace(0,d,int(SR*d),endpoint=False)
def noise(d): return rng.standard_normal(int(SR*d))
def bp(x,lo,hi):
    b,a=butter(2,[lo/(SR/2),min(hi,SR/2-100)/(SR/2)],btype="band"); return lfilter(b,a,x)
def lp(x,f):
    b,a=butter(2,f/(SR/2),btype="low"); return lfilter(b,a,x)
def hp(x,f):
    b,a=butter(2,f/(SR/2),btype="high"); return lfilter(b,a,x)
def env(d,a=0.01,r=None,curve=2.0):
    t=T(d); r=r or d-a
    e=np.minimum(t/a,1)*np.exp(-curve*np.maximum(t-a,0)/max(r,1e-3)*2)
    return e
def sweep(d,f0,f1,exp=True):
    t=T(d)
    f=f0*(f1/f0)**(t/d) if exp else f0+(f1-f0)*t/d
    return np.sin(2*np.pi*np.cumsum(f)/SR)
def sine(d,f): return np.sin(2*np.pi*f*T(d))
def pad(x,n): return np.pad(x,(0,max(0,n-len(x))))[:n]
def mixl(*parts):
    n=max(len(p) for p in parts); return sum(pad(p,n) for p in parts)
def echo(x,delay=0.09,fb=0.35,n=4):
    out=np.copy(x); out=np.pad(out,(0,int(SR*delay*n)))
    for i in range(1,n+1):
        s=int(SR*delay*i); out[s:s+len(x)]+=x*(fb**i)
    return out
def save(name,x,gain=0.9):
    x=x/np.max(np.abs(x)+1e-9)*gain
    f=int(SR*0.01); x[-f:]*=np.linspace(1,0,f)
    wavfile.write("/tmp/s.wav",SR,(x*32767).astype(np.int16))
    subprocess.run(["ffmpeg","-y","-loglevel","error","-i","/tmp/s.wav","-ac","1","-c:a","libvorbis","-q:a","5",f"{OUT}/{name}.ogg"],check=True)
def whoosh(d,lo,hi,peak=0.4):
    t=T(d); n=bp(noise(d),lo,hi); shape=np.sin(np.pi*np.clip(t/d,0,1))**1.5
    return n*shape
def thump(d,f0,f1,curve=6): return sweep(d,f0,f1)*env(d,0.003,d,curve)
def snap(d,lo=2000): return hp(noise(d),lo)*env(d,0.001,d,8)
def ring(d,f,det=1.005): return (sine(d,f)+0.5*sine(d,f*2.76)+0.3*sine(d,f*det*5.4))*env(d,0.002,d,4)
def crackle(d,dens=60):
    x=np.zeros(int(SR*d)); idx=rng.integers(0,len(x),int(dens*d))
    x[idx]=rng.uniform(-1,1,len(idx)); return lp(x,6000)*np.exp(-3*T(d)/d)

# ---------- Eclipse Reaper
save("reaper_slash", mixl(whoosh(0.45,500,7000)*1.0, sweep(0.4,700,160)*env(0.4,0.02,0.4,3)*0.35, ring(0.7,1500)*0.12))
save("reaper_dash", mixl(whoosh(0.35,300,5000)*0.9, sweep(0.3,120,1100)*env(0.3,0.02,0.3,3)*0.4, thump(0.2,120,50)*0.5))
a=np.concatenate([sine(0.18,f)*env(0.18,0.005,0.18,3) for f in (392,523,659,880)])
save("soul_harvest", echo(a*0.6+hp(noise(0.72),4000)*env(0.72,0.1,0.6,3)*0.04,0.11,0.45,4))
t=T(1.0); mod=(0.55+0.45*np.sin(2*np.pi*11*t))
save("death_spiral", mixl(bp(noise(1.0),300,5000)*mod*np.sin(np.pi*np.clip(t,0,1))**0.6, sine(1.0,90)*0.25*mod, ring(1.0,900)*0.1))
d=2.0; t=T(d)
save("black_hole_charge", mixl(sweep(d,40,260)*(0.6+0.4*np.sin(2*np.pi*7*t))*np.minimum(t/0.4,1)*0.8, bp(noise(d),80,900)*(t/d)**1.5*0.7, sweep(d,900,100)*0.12*np.sin(np.pi*t/d)))
save("black_hole_explode", mixl(thump(1.6,95,24,3)*1.0, lp(noise(1.5),900)*env(1.5,0.005,1.5,3)*0.7, bp(noise(1.2),2000,9000)*env(1.2,0.002,1.2,6)*0.4, crackle(1.4,120)*0.4, sweep(1.2,1200,70)*env(1.2,0.01,1.2,3)*0.3))
save("execution", mixl(snap(0.25,1500)*0.8, ring(0.9,740)*0.5, thump(0.35,180,45)*0.9, whoosh(0.2,1500,9000)*0.5))
# ---------- Titanbreaker
save("gauntlet_punch", mixl(thump(0.28,170,55)*1.0, snap(0.12,2500)*0.5, ring(0.25,1900)*0.18, lp(noise(0.2),1200)*env(0.2,0.002,0.2,6)*0.5))
save("rocket_punch", mixl(whoosh(0.55,200,6000)*0.8, sweep(0.5,90,700)*env(0.5,0.05,0.5,2)*0.35, thump(0.5,140,35,4)*0.8, snap(0.2,3000)*0.4))
save("ground_slam", mixl(thump(1.2,90,26,3.5)*1.0, lp(noise(1.1),500)*env(1.1,0.004,1.1,3)*0.8, crackle(1.0,90)*0.5, snap(0.15,1500)*0.5))
d=1.1; t=T(d)
save("gravity_pull", mixl(sweep(d,90,520)*(0.7+0.3*np.sin(2*np.pi*14*t))*np.sin(np.pi*t/d)**0.7*0.7, bp(noise(d),200,3000)*(t/d)*0.35, sweep(d,1400,200)*0.1))
hb=lambda: thump(0.18,110,45,5)
a=np.zeros(int(SR*0.9)); 
for s,g in ((0,1.0),(0.17,0.8)): a[int(SR*s):int(SR*s)+len(hb())]+=hb()*g
chord=sum(sine(0.8,f)*env(0.8,0.2,0.6,2) for f in (261,329,392,523))*0.12
save("adrenaline", mixl(a, np.concatenate([np.zeros(int(SR*0.1)),sweep(0.7,200,1200)*env(0.7,0.05,0.7,3)*0.3]), pad(np.concatenate([np.zeros(int(SR*0.1)),chord]),len(a))))
save("world_breaker", mixl(thump(2.2,70,18,2.5)*1.0, lp(noise(2.0),700)*env(2.0,0.003,2.0,2.5)*0.9, crackle(2.0,160)*0.6, bp(noise(1.0),1500,8000)*env(1.0,0.002,1.0,5)*0.5, thump(0.6,200,40)*np.concatenate([np.zeros(int(SR*0.25)),np.ones(int(SR*0.6)-int(SR*0.25))]) if False else 0*T(0.1)))
print(sorted(os.listdir(OUT)))
