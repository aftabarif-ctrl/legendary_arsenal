"""Procedural 32x32 animated pixel-art for the two legendary weapons."""
from PIL import Image
import math, os

OUT = "../src/main/resources/assets/legendary_arsenal/textures/item"
os.makedirs(OUT, exist_ok=True)
FRAMES = 8

def lerp(a, b, t): return tuple(int(a[i] + (b[i]-a[i])*t) for i in range(3))
def mix(c, f): return tuple(max(0, min(255, int(v*f))) for v in c)

class Canvas:
    def __init__(s): s.im = Image.new("RGBA", (32, 32), (0, 0, 0, 0)); s.px = s.im.load()
    def set(s, x, y, c, a=255):
        if 0 <= x < 32 and 0 <= y < 32: s.px[x, y] = (*c[:3], a)
    def get(s, x, y): return s.px[x, y]
    def line(s, p0, p1, c, w=1):
        x0, y0 = p0; x1, y1 = p1
        n = int(max(abs(x1-x0), abs(y1-y0))*2)+1
        for i in range(n+1):
            t = i/n; x = round(x0+(x1-x0)*t); y = round(y0+(y1-y0)*t)
            for dx in range(w):
                for dy in range(w): s.set(x+dx, y+dy, c)
    def rect(s, x, y, w, h, c):
        for i in range(w):
            for j in range(h): s.set(x+i, y+j, c)

def bez(p0, p1, p2, t):
    return ((1-t)**2*p0[0]+2*(1-t)*t*p1[0]+t*t*p2[0], (1-t)**2*p0[1]+2*(1-t)*t*p1[1]+t*t*p2[1])

# ---------------------------------------------------------------- ECLIPSE REAPER
def reaper(f):
    c = Canvas(); ph = f/FRAMES*2*math.pi
    pulse = 0.65+0.35*math.sin(ph)
    OUTLINE=(8,5,14); OBS1=(18,14,26); OBS2=(34,27,48); OBS3=(56,46,78)
    # handle (bottom-left -> top-right), leather wrapped
    h0, h1 = (4, 28), (21, 11)
    n = 60
    for i in range(n+1):
        t=i/n; x=h0[0]+(h1[0]-h0[0])*t; y=h0[1]+(h1[1]-h0[1])*t
        wrap = (int(t*n)//4) % 2
        col = (70,46,32) if wrap else (46,30,22)
        for dx in (0,1):
            for dy in (0,1): c.set(round(x)+dx, round(y)+dy, col)
    for i in range(n+1):  # handle outline highlights
        t=i/n; x=round(h0[0]+(h1[0]-h0[0])*t); y=round(h0[1]+(h1[1]-h0[1])*t)
        c.set(x-1, y+1, OUTLINE); c.set(x+2, y, OUTLINE) if t>0.1 else None
    # pommel crystal (glowing)
    cg = lerp((160,40,255),(255,60,110),pulse)
    c.rect(1,27,4,4,OUTLINE); c.rect(2,28,2,2,cg); c.set(2,28,(255,230,255)); c.set(1,27,mix(cg,0.6)); c.set(4,30,mix(cg,0.6))
    # glow halo
    for dx,dy in ((0,-1),(1,-1),(-1,0),(4,0)):
        pass
    # blade: spine bezier & edge bezier
    spine=[((26,9),(14,-6),(2,15)), ]
    P0,P1,P2 = (25,9),(15,-5),(2,15)      # spine
    Q0,Q1,Q2 = (22,12),(15,3),(3,15)      # edge
    N=70
    pts=[]
    for i in range(N+1):
        t=i/N
        a=bez(P0,P1,P2,t); b=bez(Q0,Q1,Q2,t)
        pts.append((t,a,b))
        m=max(1,int(math.hypot(a[0]-b[0],a[1]-b[1])*2))
        for k in range(m+1):
            u=k/m; x=a[0]+(b[0]-a[0])*u; y=a[1]+(b[1]-a[1])*u
            col = lerp(OBS3,OBS1,u) if u<0.5 else lerp(OBS1,OBS2,(u-0.5)*2)
            c.set(round(x),round(y),col)
    # outline spine
    for t,a,b in pts:
        c.set(round(a[0]),round(a[1])-1,OUTLINE); c.set(round(a[0])-1,round(a[1]),OUTLINE)
    # glowing animated edge (flowing highlight)
    for t,a,b in pts:
        flow = 0.5+0.5*math.sin(ph - t*9)
        col = lerp((120,10,40),(255,70,90),flow*pulse)
        c.set(round(b[0]),round(b[1]),col)
        if flow>0.85: c.set(round(b[0])+1,round(b[1])+1,mix(col,0.7))
    # runes along middle
    for idx,t in enumerate((0.18,0.38,0.58,0.78)):
        a=bez(P0,P1,P2,t); b=bez(Q0,Q1,Q2,t)
        x=round(a[0]+(b[0]-a[0])*0.48); y=round(a[1]+(b[1]-a[1])*0.48)
        glow = 0.55+0.45*math.sin(ph*1.0 + idx*1.4)
        col = lerp((110,40,200),(235,90,255),glow)
        c.set(x,y,col)
        if idx%2==0: c.set(x+1,y,mix(col,0.75))
        else: c.set(x,y+1,mix(col,0.75))
    # collar where blade meets handle
    c.rect(20,9,4,4,OUTLINE); c.rect(21,10,2,2,(90,70,120)); c.set(21,10,cg)
    # dark mist & soul flames drifting off the edge (animated)
    for k in range(7):
        t=(k/7+f/FRAMES*0.5)%1
        a=bez(Q0,Q1,Q2,t)
        drift=((f+k*2)%FRAMES)/FRAMES
        x=round(a[0]-1-drift*2); y=round(a[1]+1+drift*3)
        if c.get(x,y)[3]==0 if 0<=x<32 and 0<=y<32 else False:
            c.set(x,y,(90,40,130),int(150*(1-drift)))
    # orbiting soul fragments
    for k in range(3):
        ang=ph+k*2.094
        x=round(11+9*math.cos(ang)); y=round(9+7*math.sin(ang)*0.8-1)
        sc=lerp((120,255,240),(190,140,255),(k/3))
        if 0<=x<32 and 0<=y<32 and c.get(x,y)[3]==0:
            c.set(x,y,sc); c.set(x,y-1,mix(sc,0.6),180)
            if k==0: c.set(x+1,y,mix(sc,0.5),120)
    return c.im

# ---------------------------------------------------------------- TITANBREAKER GAUNTLETS
def gauntlet(c, ox, f, phase):
    ph = f/FRAMES*2*math.pi + phase
    OL=(52,40,22); G1=(255,226,140); G2=(214,172,76); G3=(150,108,40); W1=(250,250,246); W2=(205,208,214); W3=(150,156,170)
    pulse=0.5+0.5*math.sin(ph)
    # forearm cuff
    c.rect(ox+3,23,10,7,OL)
    c.rect(ox+4,24,8,5,G2); c.rect(ox+4,24,8,1,G1); c.rect(ox+4,28,8,1,G3)
    c.rect(ox+6,25,4,3,W2); c.rect(ox+6,25,4,1,W1)
    # palm / back-of-hand plate
    c.rect(ox+2,12,12,12,OL)
    c.rect(ox+3,13,10,10,W2)
    c.rect(ox+3,13,10,2,W1); c.rect(ox+3,21,10,2,W3)
    c.rect(ox+3,13,1,10,W1); c.rect(ox+12,13,1,10,W3)
    # gold trim
    c.rect(ox+3,22,10,1,G2); c.rect(ox+3,13,10,1,G1)
    for x in (3,12): c.set(ox+x,22,G3)
    # blue energy core (palm)
    core=lerp((40,140,255),(190,250,255),pulse)
    c.rect(ox+5,15,6,6,OL)
    c.rect(ox+6,16,4,4,lerp((20,80,200),core,0.6))
    c.rect(ox+7,17,2,2,core); c.set(ox+7,17,(255,255,255))
    # animated energy veins from the core
    vein=[(ox+8,15),(ox+8,14),(ox+7,14),(ox+6,13)], [(ox+8,21),(ox+8,22),(ox+9,22)], [(ox+5,18),(ox+4,18),(ox+4,17)], [(ox+11,18),(ox+12,18),(ox+12,19)]
    for vi,v in enumerate(vein):
        for i,(x,y) in enumerate(v):
            glow=0.5+0.5*math.sin(ph*2 - i*1.3 - vi)
            c.set(x,y,lerp((30,110,230),(170,240,255),glow))
    # four fingers: mechanical joints + crystal knuckles
    for i in range(4):
        fx=ox+2+i*3
        c.rect(fx,6,3,7,OL)
        c.rect(fx,7+0,2,5,W2); c.set(fx,7,W1); c.set(fx,8,W1)
        c.rect(fx,9,2,1,G3)          # joint
        c.set(fx+1,12,G2)
        glow=0.5+0.5*math.sin(ph*2+i*0.9)
        k=lerp((60,170,255),(210,255,255),glow)
        c.rect(fx,4,2,3,OL); c.rect(fx,5,2,2,k) ; c.set(fx,5,(255,255,255) if glow>0.8 else k)
    # thumb
    c.rect(ox+13,14,3,5,OL) if ox+13<32 else None
    c.rect(ox+13,15,2,3,W2); c.set(ox+13,15,W1); c.set(ox+14,17,(70,175,255))
    # punch-trail wisps
    for k in range(2):
        t=(f+k*4)%FRAMES
        x=ox+1+(k*9)%14; y=2+ (t%4)
        if c.get(x,y)[3]==0: c.set(x,y,(120,210,255),110-t*8)

def gauntlets(f):
    c=Canvas()
    gauntlet(c,0,f,0.0)
    gauntlet(c,15 if False else 16,f,1.3)
    return c.im

def strip(fn, name, frametime):
    frames=[fn(i) for i in range(FRAMES)]
    sheet=Image.new("RGBA",(32,32*FRAMES))
    for i,fr in enumerate(frames): sheet.paste(fr,(0,32*i))
    sheet.save(f"{OUT}/{name}.png")
    with open(f"{OUT}/{name}.png.mcmeta","w") as fh:
        fh.write('{"animation":{"interpolate":true,"frametime":%d}}'%frametime)
    # preview
    big=Image.new("RGBA",(32*8*FRAMES//2,32*8),(30,30,36,255))
    for i in range(FRAMES//2):
        big.paste(frames[i*2].resize((256,256),Image.NEAREST),(i*256,0),frames[i*2].resize((256,256),Image.NEAREST))
    big.save(f"/home/claude/mod/tools/preview_{name}.png")

strip(reaper,"eclipse_reaper",3)
strip(gauntlets,"titanbreaker_gauntlets",3)
print("ok")
